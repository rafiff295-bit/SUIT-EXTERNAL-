# MYZO Button-Only Admin + Seller Panel

All management actions are through Telegram inline buttons. `/start` only opens the panel. A few data-entry steps (custom key name, numeric Telegram ID, quota and broadcast text) require a message because the values cannot be selected from fixed buttons.

## Included
- Owner Home Admin Panel: Keys, Instances, IPA status, Users, Stats, Sellers, Admins, Broadcast
- Seller Panel: Create Key, My Keys, My Stats, Profile
- Key creation wizard: instance selection, duration, device limit, regular/custom key, key count
- Key management: details, block, delete (owner/admin), reset device counter
- Seller management: add by numeric Telegram ID, quota presets, disable seller
- Admin management: add/remove admin accounts stored in the database
- SQLite persistence

## Setup
1. Create a bot using Telegram `@BotFather`.
2. Install Python 3.11 or newer.
3. `python -m pip install -r requirements.txt`
4. Set environment variables from `.env.example`:
   - `TELEGRAM_BOT_TOKEN`: BotFather token
   - `ADMIN_IDS`: your numeric Telegram user ID (comma-separated for multiple owners)
   - `DB_PATH`: optional SQLite path
5. Run `python bot.py` on an always-on host.

Do not place tokens in source code or commit them to GitHub. Use host secret/environment settings.

## Important integration note
This panel stores keys in its own SQLite database. It does not activate or manage an IPA until a compatible API backend is implemented and the app is configured to use that API. The supplied app source was observed with an empty API base URL/offline build setting. Do not bypass app-side signature verification or embed server signing secrets in the IPA.

## Notes
- The configured instance list is a catalogue shown in the panel. It does not change app internals by itself.
- For production, use a persistent server/database, backups, and rate limits. The first release is a starter and should be tested before real use.
