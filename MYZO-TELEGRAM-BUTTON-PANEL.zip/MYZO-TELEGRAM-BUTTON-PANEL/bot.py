import os, sqlite3, secrets, string, logging, html
from datetime import datetime, timedelta, timezone
from telegram import Update, InlineKeyboardButton as B, InlineKeyboardMarkup as K
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, ContextTypes, filters

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
ADMIN_IDS = {int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()}
DB_PATH = os.getenv("DB_PATH", "myzo_panel.db")
INSTANCES = ["AIMBODY", "AIMBOT", "AIMSILENT", "INJECT MENU", "AIMNECK", "AIMDRAG", "3DHOLO", "MAGICBULLET", "FPSBOOST"]
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("myzo-panel")

def now():
    return datetime.now(timezone.utc)
def iso():
    return now().isoformat(timespec="seconds")
def db():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    c.execute("""CREATE TABLE IF NOT EXISTS keys(
      id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE NOT NULL, owner_id INTEGER NOT NULL,
      created_at TEXT NOT NULL, expires_at TEXT, status TEXT NOT NULL DEFAULT 'active',
      device_limit INTEGER NOT NULL DEFAULT 1, devices_used INTEGER NOT NULL DEFAULT 0,
      instances TEXT NOT NULL DEFAULT '', kind TEXT NOT NULL DEFAULT 'Regular', seller_id INTEGER,
      note TEXT DEFAULT '')""")
    c.execute("""CREATE TABLE IF NOT EXISTS sellers(
      user_id INTEGER PRIMARY KEY, username TEXT DEFAULT '', quota INTEGER NOT NULL DEFAULT 0,
      used INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'active', added_at TEXT NOT NULL)""")
    c.execute("""CREATE TABLE IF NOT EXISTS admins(
      user_id INTEGER PRIMARY KEY, username TEXT DEFAULT '', added_at TEXT NOT NULL)""")
    c.execute("""CREATE TABLE IF NOT EXISTS users(
      user_id INTEGER PRIMARY KEY, username TEXT DEFAULT '', first_seen TEXT NOT NULL, role TEXT DEFAULT 'user')""")
    c.commit()
    return c

def esc(v): return html.escape(str(v or ""))
def is_owner(u): return bool(u and u.effective_user and u.effective_user.id in ADMIN_IDS)
def get_seller(uid):
    c=db()
    try: return c.execute("SELECT * FROM sellers WHERE user_id=? AND status='active'",(uid,)).fetchone()
    finally: c.close()
def role(u):
    if is_owner(u): return "owner"
    if not u.effective_user: return "none"
    c=db()
    try:
        a=c.execute("SELECT 1 FROM admins WHERE user_id=?",(u.effective_user.id,)).fetchone()
        s=c.execute("SELECT 1 FROM sellers WHERE user_id=? AND status='active'",(u.effective_user.id,)).fetchone()
        return "admin" if a else ("seller" if s else "user")
    finally: c.close()
def allowed(u): return role(u) in ("owner","admin","seller")
def key_code():
    alphabet=string.ascii_uppercase+string.digits
    return "MYZO-"+"-".join("".join(secrets.choice(alphabet) for _ in range(5)) for _ in range(3))
def main_kb(owner=True):
    rows=[
      [B("🔑 Keys",callback_data="menu:keys"),B("🧩 Instances",callback_data="menu:instances")],
      [B("📱 IPA",callback_data="menu:ipa"),B("👥 Users",callback_data="menu:users")],
      [B("📊 Stats",callback_data="menu:stats")],
    ]
    if owner:
        rows += [[B("🧑‍💼 Sellers",callback_data="menu:sellers"),B("🛡 Admins",callback_data="menu:admins")],
                 [B("📣 Broadcast",callback_data="menu:broadcast")]]
    rows += [[B("🔄 Refresh",callback_data="menu:home"),B("ℹ️ Help",callback_data="menu:help")]]
    return K(rows)
def back(dest="menu:home"):
    return K([[B("⬅️ Back",callback_data=dest),B("🏠 Home",callback_data="menu:home")]])
async def say_home(q, context, user):
    r=role(user)
    c=db()
    try:
        total=c.execute("SELECT COUNT(*) FROM keys").fetchone()[0]
        active=c.execute("SELECT COUNT(*) FROM keys WHERE status='active'").fetchone()[0]
        sellers=c.execute("SELECT COUNT(*) FROM sellers WHERE status='active'").fetchone()[0]
        admins=c.execute("SELECT COUNT(*) FROM admins").fetchone()[0]+len(ADMIN_IDS)
        instances=c.execute("SELECT COUNT(*) FROM keys WHERE status='active'").fetchone()[0]
    finally: c.close()
    if r in ("owner","admin"):
        text=(f"👑 <b>MYZO — Home Admin Panel</b>\n\n"
              f"🔑 Keys: <b>{active} active / {total} total</b>\n"
              f"🧩 Active key records: <b>{instances}</b>\n"
              f"🧑‍💼 Sellers: <b>{sellers}</b>\n"
              f"🛡 Admins: <b>{admins}</b>\n"
              f"🤖 Bot: <b>Online</b>\n\nChoose an option below.")
        await q.edit_message_text(text,parse_mode="HTML",reply_markup=main_kb(r=="owner"))
    elif r=="seller":
        c=db()
        try:
            s=c.execute("SELECT * FROM sellers WHERE user_id=?",(user.effective_user.id,)).fetchone()
            mytotal=c.execute("SELECT COUNT(*) FROM keys WHERE seller_id=?",(user.effective_user.id,)).fetchone()[0]
            myactive=c.execute("SELECT COUNT(*) FROM keys WHERE seller_id=? AND status='active'",(user.effective_user.id,)).fetchone()[0]
        finally:c.close()
        text=(f"🧑‍💼 <b>MYZO — Seller Panel</b>\n\n"
              f"🆔 ID: <code>{user.effective_user.id}</code>\n"
              f"🎟 Quota: <b>{s['used']}/{s['quota'] if s['quota'] else 'Unlimited'}</b>\n"
              f"🔑 My keys: <b>{myactive} active / {mytotal} total</b>\n"
              f"🤖 Bot: <b>Online</b>\n\nChoose an option below.")
        kb=K([[B("🔑 Create Key",callback_data="menu:generate"),B("📋 My Keys",callback_data="menu:keys")],
              [B("📊 My Stats",callback_data="menu:stats"),B("👤 My Profile",callback_data="seller:profile")],
              [B("🔄 Refresh",callback_data="menu:home")]])
        await q.edit_message_text(text,parse_mode="HTML",reply_markup=kb)
    else:
        await q.edit_message_text("⛔ Access denied. Ask the panel owner to add you.",reply_markup=K([[B("🔄 Check Again",callback_data="menu:home")]]))

async def start(update:Update, context:ContextTypes.DEFAULT_TYPE):
    u=update.effective_user
    c=db()
    try:
        c.execute("INSERT INTO users(user_id,username,first_seen,role) VALUES(?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET username=excluded.username",
                  (u.id,u.username or "",iso(),role(update)))
        c.commit()
    finally:c.close()
    await update.effective_message.reply_text("Opening panel…")
    msg=update.effective_message
    # Send the panel in a fresh message; all actions after this are inline-button driven.
    fake=None
    r=role(update)
    if r in ("owner","admin"):
        c=db()
        try:
            total=c.execute("SELECT COUNT(*) FROM keys").fetchone()[0]
            active=c.execute("SELECT COUNT(*) FROM keys WHERE status='active'").fetchone()[0]
            sellers=c.execute("SELECT COUNT(*) FROM sellers WHERE status='active'").fetchone()[0]
            admins=c.execute("SELECT COUNT(*) FROM admins").fetchone()[0]+len(ADMIN_IDS)
        finally:c.close()
        await msg.reply_text(f"👑 MYZO — Home Admin Panel\n\n🔑 Keys: {active} active / {total} total\n🧩 Instances: {len(INSTANCES)} configured\n🧑‍💼 Sellers: {sellers}\n🛡 Admins: {admins}\n🤖 Bot: Online",reply_markup=main_kb(r=="owner"))
    elif r=="seller":
        c=db()
        try:
            s=c.execute("SELECT * FROM sellers WHERE user_id=?",(u.id,)).fetchone()
            total=c.execute("SELECT COUNT(*) FROM keys WHERE seller_id=?",(u.id,)).fetchone()[0]
            active=c.execute("SELECT COUNT(*) FROM keys WHERE seller_id=? AND status='active'",(u.id,)).fetchone()[0]
        finally:c.close()
        await msg.reply_text(f"🧑‍💼 MYZO — Seller Panel\n\n🆔 ID: {u.id}\n🎟 Quota: {s['used']}/{s['quota'] or 'Unlimited'}\n🔑 My keys: {active} active / {total} total\n🤖 Bot: Online",reply_markup=K([[B("🔑 Create Key",callback_data="menu:generate"),B("📋 My Keys",callback_data="menu:keys")],[B("📊 My Stats",callback_data="menu:stats"),B("👤 My Profile",callback_data="seller:profile")],[B("🔄 Refresh",callback_data="menu:home")]]))
    else:
        await msg.reply_text("⛔ You are not registered in this panel. Contact the owner.")

def inst_kb(selected, prefix="flow:inst"):
    rows=[]
    for i in range(0,len(INSTANCES),2):
        row=[]
        for item in INSTANCES[i:i+2]:
            mark="✅ " if item in selected else "▫️ "
            row.append(B(mark+item,callback_data=f"{prefix}:toggle:{INSTANCES.index(item)}"))
        rows.append(row)
    rows += [[B("☑️ All",callback_data=f"{prefix}:all"),B("🧹 None",callback_data=f"{prefix}:none")],
             [B("➡️ Next: Duration",callback_data="flow:duration"),B("❌ Cancel",callback_data="menu:home")]]
    return K(rows)
async def show_keys(q,context,page=0):
    uid=q.from_user.id; r=role_from_id(uid)
    c=db()
    try:
        if r=="seller":
            total=c.execute("SELECT COUNT(*) FROM keys WHERE seller_id=?",(uid,)).fetchone()[0]
            rows=c.execute("SELECT * FROM keys WHERE seller_id=? ORDER BY id DESC LIMIT 6 OFFSET ?",(uid,page*6)).fetchall()
        else:
            total=c.execute("SELECT COUNT(*) FROM keys").fetchone()[0]
            rows=c.execute("SELECT * FROM keys ORDER BY id DESC LIMIT 6 OFFSET ?",(page*6,)).fetchall()
    finally:c.close()
    lines=[f"🔑 <b>KEY MANAGEMENT · Page {page+1}</b>"]
    kb=[]
    for row in rows:
        status=row["status"].upper()
        exp=row["expires_at"][:10] if row["expires_at"] else "Never"
        lines.append(f"\n<code>{esc(row['code'])}</code>\nStatus: {status} · Expiry: {exp}\nDevices: {row['devices_used']}/{row['device_limit'] if row['device_limit'] else 'Unlimited'}")
        kb.append([B(("🛑 " if row["status"]=="active" else "🔎 ")+row["code"][-11:],callback_data=f"key:{row['id']}")])
    if not rows: lines.append("\nNo keys yet.")
    nav=[]
    if page: nav.append(B("⬅️ Prev",callback_data=f"keys:page:{page-1}"))
    if (page+1)*6<total: nav.append(B("Next ➡️",callback_data=f"keys:page:{page+1}"))
    if nav:kb.append(nav)
    kb += [[B("➕ Create Key",callback_data="menu:generate")],[B("⬅️ Home",callback_data="menu:home")]]
    await q.edit_message_text("\n".join(lines),parse_mode="HTML",reply_markup=K(kb))
def role_from_id(uid):
    if uid in ADMIN_IDS:return "owner"
    c=db()
    try:
        if c.execute("SELECT 1 FROM admins WHERE user_id=?",(uid,)).fetchone():return "admin"
        if c.execute("SELECT 1 FROM sellers WHERE user_id=? AND status='active'",(uid,)).fetchone():return "seller"
        return "user"
    finally:c.close()
async def key_detail(q,key_id):
    c=db()
    try:r=c.execute("SELECT * FROM keys WHERE id=?",(key_id,)).fetchone()
    finally:c.close()
    if not r or (role_from_id(q.from_user.id)=="seller" and r["seller_id"]!=q.from_user.id):
        await q.edit_message_text("Key not found.",reply_markup=back("menu:keys"));return
    exp=r["expires_at"] or "Never"
    text=(f"🔑 <b>Key Details</b>\n\nKey: <code>{esc(r['code'])}</code>\nStatus: <b>{r['status'].upper()}</b>\n"
          f"Expiry: {esc(exp)}\nDevice limit: {r['device_limit'] or 'Unlimited'}\nDevices used: {r['devices_used']}\n"
          f"Instances: {esc(r['instances'])}\nType: {esc(r['kind'])}\nSeller ID: {r['seller_id'] or 'Owner'}")
    kb=[]
    if r["status"]=="active":kb.append([B("🛑 Block Key",callback_data=f"key:block:{key_id}"),B("♻️ Reset Devices",callback_data=f"key:reset:{key_id}")])
    if role_from_id(q.from_user.id) in ("owner","admin"):kb.append([B("🗑 Delete Key",callback_data=f"key:delete:{key_id}")])
    kb += [[B("⬅️ Keys",callback_data="menu:keys"),B("🏠 Home",callback_data="menu:home")]]
    await q.edit_message_text(text,parse_mode="HTML",reply_markup=K(kb))
async def stats(q):
    uid=q.from_user.id;r=role_from_id(uid);c=db()
    try:
        if r=="seller":
            total=c.execute("SELECT COUNT(*) FROM keys WHERE seller_id=?",(uid,)).fetchone()[0]
            active=c.execute("SELECT COUNT(*) FROM keys WHERE seller_id=? AND status='active'",(uid,)).fetchone()[0]
            revoked=c.execute("SELECT COUNT(*) FROM keys WHERE seller_id=? AND status='blocked'",(uid,)).fetchone()[0]
            quota=c.execute("SELECT quota,used FROM sellers WHERE user_id=?",(uid,)).fetchone()
            text=f"📊 MY SELLER STATS\n\nTotal keys: {total}\nActive: {active}\nBlocked: {revoked}\nQuota used: {quota['used']}/{quota['quota'] or 'Unlimited'}"
        else:
            total=c.execute("SELECT COUNT(*) FROM keys").fetchone()[0]
            active=c.execute("SELECT COUNT(*) FROM keys WHERE status='active'").fetchone()[0]
            blocked=c.execute("SELECT COUNT(*) FROM keys WHERE status='blocked'").fetchone()[0]
            sellers=c.execute("SELECT COUNT(*) FROM sellers WHERE status='active'").fetchone()[0]
            text=f"📊 MYZO STATISTICS\n\n🔑 Total keys: {total}\n🟢 Active: {active}\n🛑 Blocked: {blocked}\n🧑‍💼 Sellers: {sellers}\n🧩 Configured instances: {len(INSTANCES)}"
    finally:c.close()
    await q.edit_message_text(text,reply_markup=back())
async def on_button(update:Update,context:ContextTypes.DEFAULT_TYPE):
    q=update.callback_query;await q.answer()
    uid=q.from_user.id;r=role_from_id(uid);data=q.data or ""
    if r not in ("owner","admin","seller"):
        await q.edit_message_text("⛔ Access denied.");return
    try:
        if data=="menu:home": await say_home(q,context,update)
        elif data=="menu:keys": await show_keys(q,context,0)
        elif data.startswith("keys:page:"):await show_keys(q,context,int(data.rsplit(":",1)[1]))
        elif data=="menu:generate":
            context.user_data["flow"]={"step":"instances","instances":[],"days":30,"devices":1,"kind":"Regular","count":1}
            await q.edit_message_text("🧩 <b>Create Key — Step 1/5: Select Instances</b>\n\nTap each instance to select. You can select more than one.",parse_mode="HTML",reply_markup=inst_kb([]))
        elif data.startswith("flow:inst:toggle:"):
            f=context.user_data.get("flow",{});idx=int(data.rsplit(":",1)[1]);item=INSTANCES[idx]
            s=f.setdefault("instances",[])
            if item in s:s.remove(item)
            else:s.append(item)
            await q.edit_message_text("🧩 <b>Create Key — Step 1/5: Select Instances</b>\n\nTap to select or deselect.",parse_mode="HTML",reply_markup=inst_kb(s))
        elif data=="flow:inst:all":
            f=context.user_data["flow"];f["instances"]=INSTANCES.copy()
            await q.edit_message_text("🧩 <b>Select Instances</b>",parse_mode="HTML",reply_markup=inst_kb(f["instances"]))
        elif data=="flow:inst:none":
            f=context.user_data["flow"];f["instances"]=[]
            await q.edit_message_text("🧩 <b>Select Instances</b>",parse_mode="HTML",reply_markup=inst_kb([]))
        elif data=="flow:duration":
            f=context.user_data.get("flow",{})
            if not f.get("instances"):await q.answer("Select at least one instance first.",show_alert=True);return
            await q.edit_message_text("🗓 <b>Step 2/5: Choose Duration</b>",parse_mode="HTML",reply_markup=K([[B("1 Day",callback_data="flow:days:1"),B("3 Days",callback_data="flow:days:3"),B("7 Days",callback_data="flow:days:7")],[B("30 Days",callback_data="flow:days:30"),B("90 Days",callback_data="flow:days:90"),B("♾ Never",callback_data="flow:days:0")],[B("⬅️ Back",callback_data="menu:generate"),B("Cancel",callback_data="menu:home")]]))
        elif data.startswith("flow:days:"):
            context.user_data["flow"]["days"]=int(data.rsplit(":",1)[1])
            await q.edit_message_text("📱 <b>Step 3/5: Device Limit</b>",parse_mode="HTML",reply_markup=K([[B("1 Device",callback_data="flow:devices:1"),B("2 Devices",callback_data="flow:devices:2")],[B("3 Devices",callback_data="flow:devices:3"),B("5 Devices",callback_data="flow:devices:5")],[B("10 Devices",callback_data="flow:devices:10"),B("Unlimited",callback_data="flow:devices:0")],[B("⬅️ Back",callback_data="flow:duration")]]))
        elif data.startswith("flow:devices:"):
            context.user_data["flow"]["devices"]=int(data.rsplit(":",1)[1])
            await q.edit_message_text("🎟 <b>Step 4/5: Key Type</b>",parse_mode="HTML",reply_markup=K([[B("🔑 Regular Key",callback_data="flow:kind:Regular"),B("✏️ Custom Key",callback_data="flow:kind:Custom")],[B("⬅️ Back",callback_data="flow:duration")]]))
        elif data.startswith("flow:kind:"):
            kind=data.split(":",2)[2];context.user_data["flow"]["kind"]=kind
            if kind=="Custom":
                context.user_data["flow"]["step"]="custom_name"
                await q.edit_message_text("✏️ Send the custom key name as a message. This is the only text input step; all menus are buttons.",reply_markup=K([[B("Cancel",callback_data="menu:home")]]))
            else:
                await q.edit_message_text("🔢 <b>Step 5/5: How many keys?</b>",parse_mode="HTML",reply_markup=K([[B("1",callback_data="flow:count:1"),B("5",callback_data="flow:count:5"),B("10",callback_data="flow:count:10")],[B("20",callback_data="flow:count:20"),B("⬅️ Back",callback_data="flow:devices:1")]]))
        elif data.startswith("flow:count:"):
            context.user_data["flow"]["count"]=int(data.rsplit(":",1)[1]);await create_keys(q,context,uid,r)
        elif data.startswith("key:"):
            parts=data.split(":");action=parts[1];kid=int(parts[2])
            if action=="detail":await key_detail(q,kid)
            elif action=="block":
                await q.edit_message_text("⚠️ Block this key?",reply_markup=K([[B("✅ Confirm Block",callback_data=f"key:confirmblock:{kid}"),B("Cancel",callback_data=f"key:detail:{kid}")]]))
            elif action=="confirmblock":
                c=db();c.execute("UPDATE keys SET status='blocked' WHERE id=?",(kid,));c.commit();c.close()
                await q.edit_message_text("🛑 Key blocked.",reply_markup=back("menu:keys"))
            elif action=="reset":
                c=db();c.execute("UPDATE keys SET devices_used=0 WHERE id=?",(kid,));c.commit();c.close()
                await q.edit_message_text("♻️ Device counter reset.",reply_markup=back("menu:keys"))
            elif action=="delete":
                await q.edit_message_text("⚠️ Permanently delete this key?",reply_markup=K([[B("🗑 Confirm Delete",callback_data=f"key:confirmdelete:{kid}"),B("Cancel",callback_data=f"key:detail:{kid}")]]))
            elif action=="confirmdelete":
                c=db();c.execute("DELETE FROM keys WHERE id=?",(kid,));c.commit();c.close()
                await q.edit_message_text("🗑 Key deleted.",reply_markup=back("menu:keys"))
        elif data=="menu:stats":await stats(q)
        elif data=="menu:instances":
            await q.edit_message_text("🧩 <b>Instances</b>\n\n"+ "\n".join(f"• {esc(x)}" for x in INSTANCES)+"\n\nThis list is the bot's configurable catalogue; it does not by itself change the IPA.",parse_mode="HTML",reply_markup=back())
        elif data=="menu:ipa":
            c=db();total=c.execute("SELECT COUNT(*) FROM keys").fetchone()[0];c.close()
            await q.edit_message_text(f"📱 <b>IPA / Backend Status</b>\n\n🤖 Bot: Online\n🗄 Database: Online\n🔑 Stored keys: {total}\n🔌 IPA API: Not connected yet\n\nKeys created here will not activate the IPA until its API is connected.",parse_mode="HTML",reply_markup=back())
        elif data=="menu:users":
            c=db();rows=c.execute("SELECT user_id,username,first_seen,role FROM users ORDER BY first_seen DESC LIMIT 15").fetchall();c.close()
            text="👥 <b>Recent Users</b>\n\n"+"\n".join(f"• <code>{x['user_id']}</code> @{esc(x['username']) or '—'} · {esc(x['role'])}" for x in rows)
            await q.edit_message_text(text,parse_mode="HTML",reply_markup=back())
        elif data=="menu:sellers":
            if r!="owner":await q.answer("Owner only.",show_alert=True);return
            c=db();rows=c.execute("SELECT * FROM sellers ORDER BY added_at DESC LIMIT 12").fetchall();c.close()
            kb=[[B(f"{'🟢' if x['status']=='active' else '🔴'} {x['user_id']} · {x['used']}/{x['quota'] or '∞'}",callback_data=f"seller:detail:{x['user_id']}")] for x in rows]
            kb += [[B("➕ Add Seller",callback_data="seller:add"),B("📋 My Sellers",callback_data="seller:list")],[B("🏠 Home",callback_data="menu:home")]]
            await q.edit_message_text("🧑‍💼 <b>Seller Management</b>\nSelect a seller or add one.",parse_mode="HTML",reply_markup=K(kb))
        elif data=="seller:add":
            if r!="owner":return
            context.user_data["flow"]={"step":"seller_id"}
            await q.edit_message_text("➕ Add Seller\nSend their numeric Telegram user ID or @username. Then you can set quota with buttons.",reply_markup=K([[B("Cancel",callback_data="menu:sellers")]]))
        elif data=="seller:list":
            c=db();rows=c.execute("SELECT * FROM sellers ORDER BY added_at DESC").fetchall();c.close()
            kb=[[B(f"{x['user_id']} · quota {x['quota'] or '∞'}",callback_data=f"seller:detail:{x['user_id']}")] for x in rows]
            kb += [[B("➕ Add Seller",callback_data="seller:add")],[B("⬅️ Back",callback_data="menu:sellers")]]
            await q.edit_message_text("🧑‍💼 Sellers",reply_markup=K(kb))
        elif data.startswith("seller:detail:"):
            sid=int(data.rsplit(":",1)[1]);c=db();s=c.execute("SELECT * FROM sellers WHERE user_id=?",(sid,)).fetchone();c.close()
            if not s:await q.edit_message_text("Seller not found.",reply_markup=back("menu:sellers"));return
            await q.edit_message_text(f"🧑‍💼 <b>Seller Details</b>\n\nID: <code>{sid}</code>\nUsername: @{esc(s['username']) or '—'}\nStatus: {s['status']}\nQuota used: {s['used']}/{s['quota'] or 'Unlimited'}",parse_mode="HTML",reply_markup=K([[B("🎟 Set Quota",callback_data=f"seller:quota:{sid}"),B("⛔ Disable",callback_data=f"seller:disable:{sid}")],[B("⬅️ Sellers",callback_data="menu:sellers")]]))
        elif data.startswith("seller:quota:"):
            sid=int(data.rsplit(":",1)[1]);context.user_data["flow"]={"step":"quota","seller_id":sid}
            await q.edit_message_text("Enter new quota as a message (0 = unlimited).",reply_markup=K([[B("Cancel",callback_data="menu:sellers")]]))
        elif data.startswith("seller:disable:"):
            sid=int(data.rsplit(":",1)[1]);c=db();c.execute("UPDATE sellers SET status='disabled' WHERE user_id=?",(sid,));c.commit();c.close()
            await q.edit_message_text("Seller disabled.",reply_markup=back("menu:sellers"))
        elif data=="seller:profile":
            s=get_seller(uid)
            await q.edit_message_text(f"👤 Seller Profile\n\nID: {uid}\nQuota: {s['used']}/{s['quota'] or 'Unlimited'}",reply_markup=back())
        elif data=="menu:admins":
            if r!="owner":await q.answer("Owner only.",show_alert=True);return
            c=db();rows=c.execute("SELECT * FROM admins ORDER BY added_at DESC").fetchall();c.close()
            kb=[[B(f"🛡 {x['user_id']}",callback_data=f"admin:remove:{x['user_id']}")] for x in rows]
            kb += [[B("➕ Add Admin",callback_data="admin:add")],[B("🏠 Home",callback_data="menu:home")]]
            await q.edit_message_text("🛡 <b>Admin Management</b>\nTap an admin to remove access.",parse_mode="HTML",reply_markup=K(kb))
        elif data=="admin:add":
            if r!="owner":return
            context.user_data["flow"]={"step":"admin_id"}
            await q.edit_message_text("Send the new admin's numeric Telegram user ID.",reply_markup=K([[B("Cancel",callback_data="menu:admins")]]))
        elif data.startswith("admin:remove:"):
            aid=int(data.rsplit(":",1)[1]);c=db();c.execute("DELETE FROM admins WHERE user_id=?",(aid,));c.commit();c.close()
            await q.edit_message_text("Admin access removed.",reply_markup=back("menu:admins"))
        elif data=="menu:broadcast":
            if r!="owner":await q.answer("Owner only.",show_alert=True);return
            context.user_data["flow"]={"step":"broadcast"}
            await q.edit_message_text("📣 Send the broadcast message as text. It will be sent to users who have opened the bot.",reply_markup=K([[B("Cancel",callback_data="menu:home")]]))
        elif data=="menu:help":
            await q.edit_message_text("ℹ️ <b>MYZO Button Panel</b>\n\nUse the inline buttons to manage keys, instances, sellers, admins, users, statistics and broadcasts. Only the initial /start command opens the panel; management actions are button-driven.\n\nIPA integration requires a compatible API backend.",parse_mode="HTML",reply_markup=back())
        else:
            await q.edit_message_text("Unknown action.",reply_markup=back())
    except Exception:
        log.exception("callback failed: %s",data)
        await q.edit_message_text("⚠️ Something went wrong. Please try again.",reply_markup=back())

async def create_keys(q,context,uid,r,custom_name=None):
    f=context.user_data.get("flow",{});count=int(f.get("count",1));days=int(f.get("days",30));devices=int(f.get("devices",1))
    if r=="seller":
        c=db();s=c.execute("SELECT * FROM sellers WHERE user_id=? AND status='active'",(uid,)).fetchone();c.close()
        if not s:await q.edit_message_text("Seller access is disabled.",reply_markup=back());return
        if s["quota"] and s["used"]+count>s["quota"]:
            await q.edit_message_text("⛔ Seller quota exceeded.",reply_markup=back());return
    expires=(now()+timedelta(days=days)).isoformat(timespec="seconds") if days else None
    made=[];c=db()
    try:
        for _ in range(count):
            code=(custom_name if count==1 and custom_name else key_code())
            try:
                c.execute("INSERT INTO keys(code,owner_id,created_at,expires_at,status,device_limit,instances,kind,seller_id,note) VALUES(?,?,?,?,?,?,?,?,?,?)",
                          (code,uid,iso(),expires,"active",devices,", ".join(f.get("instances",[])),f.get("kind","Regular"),uid if r=="seller" else None,custom_name or ""))
                made.append(code)
            except sqlite3.IntegrityError:
                if custom_name: raise
        if r=="seller":c.execute("UPDATE sellers SET used=used+? WHERE user_id=?",(len(made),uid))
        c.commit()
    finally:c.close()
    exp=expires[:10]+" UTC" if expires else "Never"
    validity = f"{days} days" if days else "Never"
    text = ("✅ <b>Key Created!</b>\n\n" + "\n".join(f"<code>{esc(x)}</code>" for x in made)
            + f"\n\n🧩 Instances: {esc(', '.join(f.get('instances',[])))}"
            + f"\n🗓 Validity: {validity}"
            + f"\n📱 Device limit: {devices or 'Unlimited'}"
            + f"\n🎟 Count: {len(made)}\n⏳ Expiry: {exp}")
    await q.edit_message_text(text,parse_mode="HTML",reply_markup=K([[B("➕ Create Another",callback_data="menu:generate"),B("📋 My Keys",callback_data="menu:keys")],[B("🏠 Home",callback_data="menu:home")]]))
    context.user_data.pop("flow",None)

async def text_input(update:Update,context:ContextTypes.DEFAULT_TYPE):
    f=context.user_data.get("flow",{});step=f.get("step");uid=update.effective_user.id;r=role_from_id(uid);text=(update.effective_message.text or "").strip()
    if not step:
        await update.effective_message.reply_text("Please use the panel buttons.",reply_markup=K([[B("🏠 Open Panel",callback_data="menu:home")]]));return
    if step=="custom_name":
        if not text or len(text)>64:
            await update.effective_message.reply_text("Key name must be 1–64 characters. Try again.");return
        f["custom_name"]=text;f["step"]="count_custom"
        await update.effective_message.reply_text("How many keys?",reply_markup=K([[B("1",callback_data="flow:count:1"),B("5",callback_data="flow:count:5"),B("10",callback_data="flow:count:10")],[B("20",callback_data="flow:count:20")]]))
        return
    if step=="count_custom":
        return
    if step=="seller_id":
        if r!="owner":return
        if text.startswith("@"):
            await update.effective_message.reply_text("For security, send the seller's numeric Telegram user ID (not username).");return
        if not text.isdigit():
            await update.effective_message.reply_text("Please send a numeric Telegram user ID.");return
        f["new_seller_id"]=int(text);f["step"]="seller_quota"
        await update.effective_message.reply_text("Choose seller quota:",reply_markup=K([[B("10",callback_data="seller:setquota:10"),B("50",callback_data="seller:setquota:50")],[B("100",callback_data="seller:setquota:100"),B("♾ Unlimited",callback_data="seller:setquota:0")],[B("Cancel",callback_data="menu:sellers")]]))
        return
    if step=="quota":
        if not text.isdigit():await update.effective_message.reply_text("Send a number (0 = unlimited).");return
        sid=f["seller_id"];c=db();c.execute("UPDATE sellers SET quota=? WHERE user_id=?",(int(text),sid));c.commit();c.close();context.user_data.pop("flow",None)
        await update.effective_message.reply_text("✅ Quota updated.",reply_markup=K([[B("🧑‍💼 Sellers",callback_data="menu:sellers")]]));return
    if step=="admin_id":
        if r!="owner":return
        if not text.isdigit():await update.effective_message.reply_text("Send a numeric Telegram user ID.");return
        aid=int(text);c=db();c.execute("INSERT OR IGNORE INTO admins(user_id,added_at) VALUES(?,?)",(aid,iso()));c.commit();c.close();context.user_data.pop("flow",None)
        await update.effective_message.reply_text(f"✅ Admin added: {aid}",reply_markup=K([[B("🛡 Admins",callback_data="menu:admins")]]));return
    if step=="broadcast":
        if r!="owner":return
        c=db();users=c.execute("SELECT user_id FROM users").fetchall();c.close();sent=0
        for row in users:
            try:await context.bot.send_message(row["user_id"],"📣 MYZO Announcement\n\n"+text);sent+=1
            except Exception:pass
        context.user_data.pop("flow",None)
        await update.effective_message.reply_text(f"📣 Broadcast finished. Sent: {sent}/{len(users)}",reply_markup=K([[B("🏠 Home",callback_data="menu:home")]]));return
    await update.effective_message.reply_text("Please continue using the buttons.")

async def button_bridge(update:Update,context:ContextTypes.DEFAULT_TYPE):
    # Handle the add-seller quota selection and custom-key count via button presses.
    q=update.callback_query;data=q.data or ""
    if data.startswith("seller:setquota:"):
        await q.answer()
        if role_from_id(q.from_user.id)!="owner":return
        f=context.user_data.get("flow",{});sid=f.get("new_seller_id")
        if not sid:await q.edit_message_text("Seller setup expired. Start again.",reply_markup=back("menu:sellers"));return
        quota=int(data.rsplit(":",1)[1]);c=db()
        try:
            user=c.execute("SELECT username FROM users WHERE user_id=?",(sid,)).fetchone()
            c.execute("INSERT INTO sellers(user_id,username,quota,used,status,added_at) VALUES(?,?,?,0,'active',?) ON CONFLICT(user_id) DO UPDATE SET quota=excluded.quota,status='active'",
                      (sid,user["username"] if user else "",quota,iso()));c.commit()
        finally:c.close()
        context.user_data.pop("flow",None)
        await q.edit_message_text(f"✅ Seller added\nID: <code>{sid}</code>\nQuota: {quota or 'Unlimited'}",parse_mode="HTML",reply_markup=K([[B("🧑‍💼 Sellers",callback_data="menu:sellers"),B("🏠 Home",callback_data="menu:home")]]))
        return
    if data.startswith("flow:count:"):
        await q.answer()
        f=context.user_data.get("flow",{})
        if f.get("kind")=="Custom" and f.get("custom_name"):
            await create_keys(q,context,q.from_user.id,role_from_id(q.from_user.id),f["custom_name"])
        else:
            await create_keys(q,context,q.from_user.id,role_from_id(q.from_user.id))
        return
    if data.startswith("key:") and data.count(":")==1:
        await q.answer()
        await key_detail(q,int(data.split(":")[1]))
        return
    await on_button(update,context)

async def error_handler(update:object,context:ContextTypes.DEFAULT_TYPE):
    log.error("Unhandled exception",exc_info=context.error)
def main():
    if not TOKEN:raise SystemExit("Set TELEGRAM_BOT_TOKEN in environment.")
    if not ADMIN_IDS:raise SystemExit("Set ADMIN_IDS to your numeric Telegram user ID.")
    db().close()
    app=Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start",start))
    app.add_handler(CallbackQueryHandler(button_bridge))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND,text_input))
    app.add_error_handler(error_handler)
    log.info("MYZO button-only panel starting")
    app.run_polling(allowed_updates=Update.ALL_TYPES)
if __name__=="__main__":main()
